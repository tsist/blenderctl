# Standalone Linux CLI installer candidate (reconstruction R3)
Supported baseline: Linux x86-64, glibc compatible with official Blender 5.3.0, /usr/bin/python3.13, tar + xz. No admin rights, network or account required by installer. Extract the package into a new directory. Then:
    python3.13 install.py --prefix /absolute/path/to/NEW-private-prefix --blender-archive /path/to/blender-5.3.0-linux-x64.tar.xz
    /absolute/path/to/NEW-private-prefix/bin/blenderctl probe

No runtime is redistributed. Use the unmodified official Linux x64 archive from https://download.blender.org/release/Blender5.3/blender-5.3.0-linux-x64.tar.xz (SHA256 dacb8264197a3f7fda6001285a5a506fc97ee943881261c2c3bd63c882f22e05). Blender source and notices: https://download.blender.org/source/ . Only trusted local self-contained inputs; no daemon, network provider, raw Python, render or production overwrite.

This is NOT the missing byte-for-byte historical release. The three Linux backend files in base/ are newly reconstructed for this package. Upstream implementation modules derive from tsist/blenderctl main 94cebe27e402d0f2101b97942c81a58fe21a6b1f. The jobs and publication implementation derives from the GitHub PR #4 tree (commit aecd63515bed97390334a7d0ab7c0537597d968a). The standalone public entry supports only probe, scene/model prepare, bounded jobs and new-only transaction publication. The separate camera addon and other domain adapters are not installed; internal overlay helpers are not standalone commands. This is neither the full Windows product nor a restoration of every historical Linux command.

Use job submit-and-wait in short-lived container sessions. Use prefixes and output directories owned by the current user; do not reuse a partially installed destination after an interruption. No automatic update, deletion, plugin activation or global configuration change. The runtime and operator selections are fixed; host checks are not an isolation sandbox for malicious assets.

## Download and verify the external runtime (lightweight GitHub package)

    curl --fail --location --output blender-5.3.0-linux-x64.tar.xz https://download.blender.org/release/Blender5.3/blender-5.3.0-linux-x64.tar.xz
    printf '%s  %s\n' dacb8264197a3f7fda6001285a5a506fc97ee943881261c2c3bd63c882f22e05 blender-5.3.0-linux-x64.tar.xz | sha256sum --check -
    /usr/bin/python3.13 -I -B install.py --prefix "$HOME/blenderctl-linux-5.3-clean" --blender-archive "$PWD/blender-5.3.0-linux-x64.tar.xz"
    "$HOME/blenderctl-linux-5.3-clean/bin/blenderctl" probe

CLI upstream 0.63.1 (release metadata 0.63.1-r1); this rebuilt Linux distribution is separately labeled reconstruction-r3. This is not a full Blender plug-in suite. No optional add-ons are installed or enabled. Do not select the factory system Blender 4.x in place of the pinned runtime.

The standalone bundle removes camera/legacy modules, external provider dispatch and plugin launchers. The immutable prepare launcher and its expected SHA are updated together for a strictly named scene/model interface. Upstream protocol helpers for unused Windows features are not exported. This package does not claim every upstream authoring operation has been certified.

## Smoke example (from the extracted package directory)
    CTL="$HOME/blenderctl-linux-5.3-clean/bin/blenderctl"
    "$CTL" job submit-and-wait --domain scene --manifest "$PWD/smoke-scene.json"
    # Record job_id from the terminal succeeded line:
    mkdir -m 700 "$HOME/blenderctl-smoke-output"
    "$CTL" transaction publish --job-id YOUR_JOB_ID --output "$HOME/blenderctl-smoke-output/scene.blend"
    SOURCE="$HOME/blenderctl-smoke-output/scene.blend"
    HASH=$(sha256sum "$SOURCE" | cut -d ' ' -f 1)
    "$CTL" job submit-and-wait --domain model --manifest "$PWD/smoke-model.json" --source "$SOURCE" --sha "$HASH"
