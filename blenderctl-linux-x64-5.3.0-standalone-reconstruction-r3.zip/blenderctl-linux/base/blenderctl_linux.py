#!/usr/bin/python3.13
"""Reconstructed pinned host; only probe and non-rendering named prepares."""
import argparse,json,os,stat,sys,uuid
from pathlib import Path
here=Path(__file__).resolve().parent;sys.path.insert(0,str(here))
from linux_scene_guards import regular,run,put,require,PIN
sys.path.insert(0,str(here.parent/'tools/blenderctl'))
def main():
    os.umask(0o077);ap=argparse.ArgumentParser();ap.add_argument('--blender',required=True,type=Path);ap.add_argument('--jobs-dir',required=True,type=Path)
    ap.add_argument('domain',choices=('probe','scene','model'));ap.add_argument('verb',nargs='?',choices=('prepare',));ap.add_argument('--manifest',type=Path);ap.add_argument('--file',type=Path);ap.add_argument('--expected-sha256')
    a=ap.parse_args();base=here.parents[3];rt=base/'af-exterior-blender53/blender-5.3.0-linux-x64/blender';common=base/'af-exterior-linux-suite/jobs/common'
    require(a.blender==rt and regular(rt)==PIN and a.jobs_dir==common and common.resolve()==common,'untrusted runtime or job root')
    t=common.stat();require(t.st_uid==os.getuid() and stat.S_IMODE(t.st_mode)==0o700,'private root required')
    require(bool(a.file)==bool(a.expected_sha256),'source SHA required')
    if a.domain=='probe':require(not any((a.verb,a.manifest,a.file)),'probe accepts no options')
    else:require(a.verb=='prepare' and a.manifest is not None,'prepare needs manifest')
    job=common/uuid.uuid4().hex;job.mkdir(mode=0o700);work=job/'worker';work.mkdir(mode=0o700)
    cmd=a.domain+('.prepare' if a.verb else '');params={}
    try:
        if a.manifest:
            import io
            f=io.BytesIO();regular(a.manifest,1024*1024,f);m=json.loads(f.getvalue())
            from scene_contract import normalize as scene
            from model_contract import normalize as model
            (scene if a.domain=='scene' else model)(m)
            require(len(m['operations'])<=128 and all('font' not in x for x in m['operations']),'unsupported operations');params['manifest']=m
        if a.file:
            require(a.file.suffix.lower()=='.blend','blend input only');params.update(file=str(a.file),expected_sha256=a.expected_sha256)
        put(job/'request.json',{'schema_version':'1.0','command':cmd,'params':params})
        w=dict(params)
        if a.file:
            with (work/'input.blend').open('xb') as f:require(regular(a.file,destination=f)==a.expected_sha256,'source hash mismatch')
            w['file']=str(work/'input.blend')
        put(work/'task.json',{'domain':a.domain,'params':w})
        run([str(rt),'--background','--factory-startup','--disable-autoexec','--offline-mode','--threads','2','--python-exit-code','23','--python',str(here/'blenderctl_linux_worker.py'),'--',str(work)],work)
        data=json.loads((work/'worker-result.json').read_bytes())
        if a.verb:
            c=work/(a.domain+'-candidate.blend');require(data['candidate']==str(c) and data['reopen']=='pass' and regular(c)==data['candidate_sha256'],'candidate mismatch')
        if a.file:
            require(regular(a.file)==a.expected_sha256==regular(work/'input.blend'),'source changed');data.update(source_file=str(a.file),source_sha256=a.expected_sha256,source_unchanged=True)
        out={'schema_version':'1.0','job_id':job.name,'command':cmd,'ok':True,'data':data,'error':None}
    except Exception as exc:out={'schema_version':'1.0','job_id':job.name,'command':cmd,'ok':False,'data':None,'error':{'message':str(exc)}}
    put(job/'result.json',out);print(json.dumps(out));return 0 if out['ok'] else 2
if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:print(json.dumps({'ok':False,'error':str(e)}));sys.exit(2)
