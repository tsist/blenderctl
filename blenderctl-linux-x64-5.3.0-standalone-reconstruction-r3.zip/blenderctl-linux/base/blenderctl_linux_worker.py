"""Reconstructed fixed-dispatch non-rendering Blender worker, no user Python."""
import bpy,sys,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools/blenderctl'));sys.path.insert(0,str(root/'scripts'))
from linux_scene_guards import put,require,regular
work=Path(sys.argv[sys.argv.index('--')+1])
r=json.loads((work/'task.json').read_text());domain=r['domain'];params=r['params']
require(bpy.app.version[:3]==(5,3,0),'Blender 5.3.0 only')
if domain=='probe':
    result={'version':bpy.app.version_string,'build_hash':bpy.app.build_hash.decode(),'background':bool(bpy.app.background),'qualified_routes':['scene.prepare','model.prepare']}
else:
    require(domain in {'scene','model'},'unsupported')
    if 'file' in params:
        bpy.ops.wm.open_mainfile(filepath=params['file'],load_ui=False,use_scripts=False)
        require(not bpy.data.libraries and not bpy.data.texts,'no linked libraries or embedded scripts')
        refs={q for group in bpy.data.file_path_map(include_libraries=True).values() for q in group}
        for q in bpy.utils.blend_paths(absolute=False,packed=False):
            require(not q or (q not in refs and q.endswith('/datafiles/assets/brushes/essentials_brushes-gp_draw.blend')),'external file unsupported')
        require(not any(v.animation_data and v.animation_data.drivers for coll in (bpy.data.objects,bpy.data.scenes,bpy.data.materials,bpy.data.worlds) for v in coll),'drivers unsupported')
    import scenes,modeling
    result=(scenes if domain=='scene' else modeling).prepare(params,work)
put(work/'worker-result.json',result)
