"""Reconstructed Linux-only guards; fixed runtime, owner-private jobs, bounded inputs."""
import hashlib,os,stat,signal,subprocess,time,json
from pathlib import Path
CAP=512*1024*1024
PIN='baaa36cb5d7a35092388e6d123739b0829012c252b0705bc2debec292e4ebffb'
def require(x,s):
    if not x:raise ValueError(s)
def regular(path,cap=CAP,destination=None):
    p=Path(path)
    require(p.is_absolute() and p.resolve(strict=True)==p and '..' not in p.parts,'absolute non-symlink file required')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as f:
        t=os.fstat(fd);require(stat.S_ISREG(t.st_mode) and t.st_nlink==1 and t.st_size<=cap,'bad input type/size/links')
        h=hashlib.sha256();n=0
        for b in iter(lambda:f.read(1048576),b''):
            n+=len(b);require(n<=cap,'size limit');h.update(b)
            if destination:destination.write(b)
        sig=lambda s:(s.st_ino,s.st_dev,s.st_size,s.st_ctime_ns)
        require(n==t.st_size and sig(os.fstat(fd))==sig(t)==sig(p.lstat()),'file changed')
        return h.hexdigest()
def put(path,val):
    tmp=path.with_suffix('.pending');data=json.dumps(val,allow_nan=False).encode()
    with tmp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
def run(argv,work):
    stopped=[]
    def onterm(*_):stopped.append(True)
    old={s:signal.signal(s,onterm) for s in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT)}
    home=work/'home';home.mkdir(mode=0o700)
    try:
        with (work/'blender.log').open('xb') as log:
            p=subprocess.Popen(argv,cwd=work,env={'HOME':str(home),'TMPDIR':str(home),'LANG':'C.UTF-8','PATH':os.defpath,'BLENDER_USER_RESOURCES':str(home/'blender')},stdout=log,stderr=log,stdin=subprocess.DEVNULL,start_new_session=True)
            try:
                end=time.monotonic()+300
                while os.waitid(os.P_PID,p.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
                    require(not stopped and time.monotonic()<end,'cancelled/deadline');time.sleep(.05)
            finally:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                p.wait()
            require(not stopped and p.returncode==0,'Blender worker failed (see job log)')
    finally:
        for sig,handler in old.items():signal.signal(sig,handler)
