#!/usr/bin/python3
"""Install into a completely new owned private Linux prefix, without network, sudo or global configuration."""
import argparse,hashlib,json,os,shutil,stat,subprocess,sys
from pathlib import Path
ARC='dacb8264197a3f7fda6001285a5a506fc97ee943881261c2c3bd63c882f22e05'
BIN='baaa36cb5d7a35092388e6d123739b0829012c252b0705bc2debec292e4ebffb'
def require(v,s):
    if not v:raise ValueError(s)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    os.umask(0o077);p=argparse.ArgumentParser();p.add_argument('--prefix',type=Path,required=True);p.add_argument('--blender-archive',type=Path);a=p.parse_args()
    root=Path(__file__).resolve().parent;prefix=a.prefix;arc=a.blender_archive or root/'blender-5.3.0-linux-x64.tar.xz'
    require(sys.platform.startswith('linux') and os.uname().machine=='x86_64' and Path('/usr/bin/python3.13').is_file(),'Linux x86_64 with /usr/bin/python3.13 required')
    require(arc.is_file() and not arc.is_symlink() and sha(arc)==ARC,'missing or mismatched official Blender 5.3.0 archive')
    require(prefix.is_absolute() and prefix.parent.resolve(strict=True)==prefix.parent and not os.path.lexists(prefix),'new absolute prefix required')
    for d in [prefix.parent,*prefix.parent.parents]:
        s=d.stat();require(s.st_uid in (0,os.getuid()) and (not s.st_mode&0o022 or (s.st_uid==0 and s.st_mode&stat.S_ISVTX)),'unsafe parent directory')
    rows=json.loads((root/'FILES.json').read_text())
    for name,value in rows.items():
        src=root/name;require(not Path(name).is_absolute() and '..' not in Path(name).parts and src.resolve()==src and sha(src)==value,'invalid package file: '+name)
    prefix.mkdir(mode=0o700)
    runtime=prefix/'af-exterior-blender53';runtime.mkdir()
    subprocess.run(['/usr/bin/tar','-xJf',str(arc),'--no-same-owner','-C',str(runtime)],check=True)
    require(sha(runtime/'blender-5.3.0-linux-x64/blender')==BIN,'installed Blender binary mismatched')
    suite=prefix/'af-exterior-linux-suite';backend=prefix/'af-exterior-linux-dev/source/blenderctl'
    for name in rows:
        parts=Path(name).parts
        if parts[0]=='core':dest=backend/'tools/blenderctl'/parts[1]
        elif parts[0]=='base':dest=backend/'scripts'/parts[1]
        elif parts[0]=='overlay':dest=suite/Path(*parts[1:])
        elif name=='blenderctl':dest=prefix/'bin/blenderctl'
        else:continue
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,dest);dest.chmod(0o700 if 'bin' in dest.parts else 0o600)
    for n in ('common','background'):(suite/'jobs'/n).mkdir(parents=True,mode=0o700)
    print(prefix/'bin/blenderctl')
if __name__=='__main__':main()
